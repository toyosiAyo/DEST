<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="" method="post">
        <input type="file" name="cert"> <br> <br>
        <button type="submit">send</button>
    </form>
</body>
</html><?php /**PATH C:\xampp8.1.2_PHP 8.1.2\htdocs\DEST\resources\views/getForm.blade.php ENDPATH**/ ?>