 

  <?php $__env->startSection("title"); ?>
      Applications
  <?php $__env->stopSection(); ?>

  <?php $__env->startSection("content"); ?>
    <body class="animsition site-menubar-push site-menubar-open site-menubar-fixed">
        <div class="page">
        <?php if(Session::get('appSubmit')): ?>
                <p><?php echo e(Session::get('appSubmit')); ?></p>
         <?php endif; ?>
            <div class="page-content container-fluid">
                <div class="row" data-plugin="masonry">
                    <div class="col-lg-12 masonry-item">
                        <!-- Panel Tasks -->
                        <div class="panel">
                            <div class="panel-heading">
                                <h3 class="panel-title">Application(s)</h3>
                            </div>
                            <div class="table-responsive h-250" data-plugin="scrollable">
                                <div data-role="container">
                                    <div data-role="content">
                                        <table id="app_table" class="table table-responsive-sm table-hover table-striped">
                                            <thead>
                                                <tr>
                                                    <th>S/N</th>
                                                    <th>Programme</th>
                                                    <th>Date</th>
                                                    <th>Status</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $i = 1; ?>
                                                <?php $__currentLoopData = $apps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($i); ?> <?php $i++ ?></td>
                                                    <td><?php echo e($app->Programme); ?></td>
                                                    <td><?php echo e(date("d M Y", strtotime($app->updated_at))); ?></td>
                                                    <td><?php echo $app->status == 'pending' ? 
                                                        '<span class="badge badge-warning">'.$app->status.'</span>' :
                                                        '<span class="badge badge-success">'.$app->status.'</span>' ?>
                                                    </td>
                                                    <td><button type="button" class="btn btn-info view" data-id="<?php echo e($app->id); ?>" 
                                                            data-status="<?php echo e($app->status); ?>">
                                                            <i class="icon md-trending-up" aria-hidden="true"></i> View
                                                        </button>
                                                    </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Panel Tasks -->
                    </div>
                </div>
            </div>
        </div>
    </body>
    <!-- Modal -->
    <div class="modal fade modal-newspaper" id="view_app" aria-hidden="true"
        aria-labelledby="exampleModalTitle" role="dialog" tabindex="-1">
        <div class="modal-dialog modal-simple">
            <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
                </button>
                <h4 class="modal-title">Application details</h4>
            </div>
            <div class="modal-body">
                <!-- <p>My applicatioon details</p> -->
                <span id="details"></span>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default btn-pure" data-dismiss="modal">Close</button>
                <!-- <button type="button" class="btn btn-primary">Save changes</button> -->
            </div>
            </div>
        </div>
    </div>
        <!-- End Modal -->
    <script src="<?php echo e(asset('scripts/view_application.js')); ?>"></script>




  <?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8.0.11\htdocs\dest\DEST\resources\views/pages/applications.blade.php ENDPATH**/ ?>