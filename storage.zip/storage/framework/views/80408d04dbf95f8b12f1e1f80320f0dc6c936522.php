<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <script>document.write(new Date().getFullYear())</script> © RUN DEST.
            </div>
        </div>
    </div>
</footer><?php /**PATH C:\xampp8.0.11-2\htdocs\dest\DEST\resources\views/admin/partials/footer.blade.php ENDPATH**/ ?>