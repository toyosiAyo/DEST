<footer class="page-copyright">
    <p>RUN DEST</p>
    <p>© <script>document.write(new Date().getFullYear())</script></p>
    <!-- <div class="social">
    <a class="btn btn-icon btn-round social-twitter mx-5" href="javascript:void(0)">
    <i class="icon bd-twitter" aria-hidden="true"></i>
    </a>
    <a class="btn btn-icon btn-round social-facebook mx-5" href="javascript:void(0)">
    <i class="icon bd-facebook" aria-hidden="true"></i>
    </a>
    <a class="btn btn-icon btn-round social-google-plus mx-5" href="javascript:void(0)">
    <i class="icon bd-google-plus" aria-hidden="true"></i>
    </a>
    </div> -->
</footer><?php /**PATH C:\xampp8.0.11\htdocs\dest\DEST\resources\views/partials/auth_footer.blade.php ENDPATH**/ ?>