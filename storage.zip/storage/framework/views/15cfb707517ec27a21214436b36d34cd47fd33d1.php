 

  <?php $__env->startSection("title"); ?>
      Payment History
  <?php $__env->stopSection(); ?>

  <?php $__env->startSection("content"); ?>
    <body class="animsition site-menubar-push site-menubar-open site-menubar-fixed">
        <div class="page">
            <div class="page-content container-fluid">
                <div class="row" data-plugin="masonry">
                    <div class="col-lg-12 masonry-item">
                        <!-- Panel Tasks -->
                        <div class="panel">
                            <div class="panel-heading">
                                <h3 class="panel-title">Payment History</h3>
                            </div>
                            <div class="table-responsive h-250" data-plugin="scrollable">
                                <div data-role="container">
                                    <div data-role="content">
                                        <table class="table table-responsive-sm table-hover table-striped">
                                            <thead>
                                                <tr>
                                                    <th>S/N</th>
                                                    <th>Transaction ID</th>
                                                    <th>Amount</th>
                                                    <th>Date</th>
                                                    <th>Status</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $i = 1; ?>
                                                <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($i); ?> <?php $i++ ?></td>
                                                    <td><?php echo e($payment->trans_ref); ?></td>
                                                    <td><?php echo e($payment->amount); ?></td>
                                                    <td><?php echo e(date("d M Y", strtotime($payment->updated_at))); ?></td>
                                                    <td><?php echo $payment->status_msg == 'pending' ?
                                                        '<span class="badge badge-warning"> '.$payment->status_msg.'</span>' :
                                                        '<span class="badge badge-success">'.$payment->status_msg.'</span>' ?>
                                                    </td>
                                                    <td><?php echo $payment->status_msg == 'pending' ?
                                                        '<button type="button" class="btn btn-danger">
                                                            <i class="icon md-refresh" aria-hidden="true"></i> Requery
                                                        </button>' :
                                                        '<button type="button" class="btn btn-success">
                                                            <i class="icon md-print" aria-hidden="true"></i> Print Receipt
                                                        </button>' ?>
                                                    </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Panel Tasks -->
                    </div>
                </div>
            </div>
        </div>
    </body>



  <?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8.0.11-2\htdocs\dest\DEST\resources\views/pages/payment_history.blade.php ENDPATH**/ ?>