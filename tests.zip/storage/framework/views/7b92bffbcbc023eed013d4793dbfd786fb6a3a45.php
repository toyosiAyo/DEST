 

  <?php $__env->startSection("title"); ?>
      Register
  <?php $__env->stopSection(); ?>

  <?php $__env->startPush('head'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('assets/examples/css/pages/register-v2.minfd53.css?v4.0.1')); ?>">
  <script src="<?php echo e(asset('global/js/Plugin/animate-list.minfd53.js?v4.0.1')); ?>"></script>
  <?php $__env->stopPush(); ?>
  
  <?php $__env->startSection("content"); ?>

    <!-- Page -->
    <body class="animsition page-register-v2 layout-full page-dark">

    <!-- Page -->
    <div class="page" data-animsition-in="fade-in" data-animsition-out="fade-out">
      <div class="page-content">
        <div class="page-brand-info">
          <div class="brand">
            <img class="brand-img" src="../assets/images/DEST_logo.png" alt="...">
            <h1 style="color:white; background-color:darkblue; font-weight: bold; font-style: italic; font-size: 40px;">Welcome to DEST Student Portal</h1>
          </div>
          <!-- <p class="font-size-20">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
            tempor incididunt ut labore et dolore magna aliqua.</p> -->
        </div>

        <div class="page-register-main">
          <div class="brand hidden-md-up">
            <img class="brand-img" src="../assets/images/run_logo.png" alt="...">
            <h3 class="brand-text font-size-30">RUN DEST</h3>
          </div>
          <h3 class="font-size-24">Create your Profile</h3>
              <?php if(Session::get('success')): ?>
                <div class="alert dark alert-icon alert-success alert-dismissible" role="alert">
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                  <i class="icon md-close" aria-hidden="true"></i> <?php echo e(Session::get('success')); ?>

                </div>
              <?php endif; ?>
              <?php if(Session::get('fail')): ?>
                <div class="alert dark alert-icon alert-danger alert-dismissible" role="alert">
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                  <i class="icon md-close" aria-hidden="true"></i> <?php echo e(Session::get('fail')); ?>

                </div>
              <?php endif; ?>
          <form action="<?php echo e(route('save.account.form')); ?>" method="post" role="form" autocomplete="off">
            <?php echo csrf_field(); ?>
            <div class="form-group form-material floating" data-plugin="formMaterial">
              <input type="text" value="<?php echo e(old('surname')); ?>" class="form-control empty" id="surname" name="surname" required>
              <label class="floating-label" for="surname">Surname</label>
              <?php if($errors->has('surname')): ?>
                  <span class="">
                    <strong><?php echo e($errors->first('surname')); ?></strong>
                  </span>
              <?php endif; ?>
            </div>
            <div class="form-group form-material floating" data-plugin="formMaterial">
              <input type="text" value="<?php echo e(old('firstname')); ?>" class="form-control empty" id="firstname" name="firstname" required>
              <label class="floating-label" for="firstname">Firstname</label>
              <?php if($errors->has('firstname')): ?>
                  <span class="">
                    <strong><?php echo e($errors->first('firstname')); ?></strong>
                  </span>
              <?php endif; ?>
            </div>
            <div class="form-group form-material floating" data-plugin="formMaterial">
              <input type="text" value="<?php echo e(old('othername')); ?>" class="form-control empty" id="othername" name="othername" required>
              <label class="floating-label" for="othername">Othername</label>
              <?php if($errors->has('othername')): ?>
                  <span class="">
                    <strong><?php echo e($errors->first('othername')); ?></strong>
                  </span>
              <?php endif; ?>
            </div>
            <div class="form-group form-material floating" data-plugin="formMaterial">
              <input type="email" value="<?php echo e(old('email')); ?>" class="form-control empty" id="email" name="email" required>
              <label class="floating-label" for="inputEmail">Email</label>
              <?php if($errors->has('email')): ?>
                  <span class="">
                    <strong><?php echo e($errors->first('email')); ?></strong>
                  </span>
              <?php endif; ?>
            </div>
            <div class="form-group form-material floating" data-plugin="formMaterial">
              <input type="text" value="<?php echo e(old('phone')); ?>" class="form-control empty" id="phone" name="phone" required>
              <label class="floating-label" for="phone">Phone Number</label>
              <?php if($errors->has('phone')): ?>
                  <span class="">
                    <strong><?php echo e($errors->first('phone')); ?></strong>
                  </span>
              <?php endif; ?>
            </div>
            <div class="form-group form-material floating" data-plugin="formMaterial">
                  <select class="form-control" id="gender" name="gender" required>
                    <option>&nbsp;</option>
                    <option value="M">Male</option>
                    <option value="F">Female</option>
                  </select>
                  <label class="floating-label" for="gender">Gender</label>
                </div>
            <div class="form-group form-material floating" data-plugin="formMaterial">
              <input type="password" value="" class="form-control empty" id="password" name="password" required>
              <label class="floating-label" for="password">Password</label>
              <?php if($errors->has('password')): ?>
                  <span class="">
                    <strong><?php echo e($errors->first('password')); ?></strong>
                  </span>
              <?php endif; ?>
            </div>
            <div class="form-group form-material floating" data-plugin="formMaterial">
              <input type="password" value="" class="form-control empty" id="password_confirmation" name="password_confirmation" required>
              <label class="floating-label" for="password_confirmation">Confirm Password</label>
              <?php if($errors->has('password_confirmation')): ?>
                  <span class="">
                    <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                  </span>
              <?php endif; ?>
            </div>
            <button type="submit" class="btn btn-primary btn-block">Submit</button>
          </form>
          <p>Have an account already? Please go to <a href="<?php echo e(route('auth.login')); ?>">Log In</a></p>
          <?php echo $__env->make("partials.auth_footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

      </div>
    </div>
    <!-- End Page -->

    <!-- Page -->
    
    </body>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.auth", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8.0.11-2\htdocs\dest\DEST\resources\views/auth/register.blade.php ENDPATH**/ ?>