 

  <?php $__env->startSection("title"); ?>
      Verify Email
  <?php $__env->stopSection(); ?>
    
  <?php $__env->startPush('head'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('assets/examples/css/pages/forgot-password.minfd53.css?v4.0.1')); ?>">
  <?php $__env->stopPush(); ?>

  <?php $__env->startSection("content"); ?>
  <style>
      .verify-email {
        font-size: 30px;
        text-align: center;
        letter-spacing: 15px;
        
        }
  </style>
    <body class="animsition page-forgot-password layout-full">
      <div class="page vertical-align text-center" data-animsition-in="fade-in" data-animsition-out="fade-out">
        <div class="page-content vertical-align-middle">
          <h2>Verify your Email Address</h2>
            <?php if(Session::get('account_created')): ?>
                <div class="alert dark alert-icon alert-success alert-dismissible" role="alert">
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                  <i class="icon md-close" aria-hidden="true"></i> <?php echo e(Session::get('account_created')); ?>

                </div>
            <?php endif; ?>
            <?php if(Session::get('success')): ?>
                <div class="alert dark alert-icon alert-success alert-dismissible" role="alert">
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                  <i class="icon md-close" aria-hidden="true"></i> <?php echo e(Session::get('success')); ?>

                </div>
            <?php endif; ?>
            <?php if(Session::get('resend')): ?>
                <div class="alert dark alert-icon alert-success alert-dismissible" role="alert">
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                  <i class="icon md-close" aria-hidden="true"></i> <?php echo e(Session::get('resend')); ?>

                </div>
            <?php endif; ?>
            <?php if(Session::get('verify')): ?>
                <div class="alert dark alert-icon alert-danger alert-dismissible" role="alert">
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                  <i class="icon md-close" aria-hidden="true"></i> <?php echo e(Session::get('verify')); ?>

                </div>
            <?php endif; ?>
            <?php if(Session::get('fail')): ?>
                <div class="alert dark alert-icon alert-danger alert-dismissible" role="alert">
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                  <i class="icon md-close" aria-hidden="true"></i> <?php echo e(Session::get('fail')); ?>

                </div>
            <?php endif; ?>
          <p>Input the OTP sent to your registered email</p>

          <form action ="<?php echo e(route('account_activate')); ?>" method="post" role="form" autocomplete="off">
            <?php echo csrf_field(); ?>
            <div class="form-group form-material floating" data-plugin="formMaterial">
              <input type="tel" maxlength="6" class="form-control empty verify-email" id="otp" name="otp" required>
              <label class="floating-label" for="inputEmail">Enter OTP</label>
            </div>
            <div class="form-group">
              <button type="submit" class="btn btn-primary btn-block">Verify</button>
              <small>Didn't get a code? <a href="<?php echo e(route('resend_otp')); ?>">Resend</a></small>
            </div>
          </form>
          <?php echo $__env->make("partials.auth_footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
      </div>
    </body>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.auth", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8.0.11\htdocs\dest\DEST\resources\views/auth/verify.blade.php ENDPATH**/ ?>