 

  <?php $__env->startSection("title"); ?>
      Forgot Password
  <?php $__env->stopSection(); ?>
    
  <?php $__env->startPush('head'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('assets/examples/css/pages/forgot-password.minfd53.css?v4.0.1')); ?>">
  <?php $__env->stopPush(); ?>

  <?php $__env->startSection("content"); ?>
    <body class="animsition page-forgot-password layout-full">
      <div class="page vertical-align text-center" data-animsition-in="fade-in" data-animsition-out="fade-out">
        <div class="page-content vertical-align-middle">
          <h2>Forgot Your Password ?</h2>
      
            <?php if(Session::get('fail')): ?>
                <div class="alert dark alert-icon alert-danger alert-dismissible" role="alert">
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                  <i class="icon md-close" aria-hidden="true"></i> <?php echo e(Session::get('fail')); ?>

                </div>
            <?php endif; ?>
          <p>Input your registered email to reset your password</p>

          <form action ="<?php echo e(route('forgot.password')); ?>" method="post" role="form" autocomplete="off">
          <?php echo csrf_field(); ?>
          <div class="form-group form-material floating" data-plugin="formMaterial">
              <input type="email" class="form-control empty" id="inputEmail" name="email">
              <label class="floating-label" for="inputEmail">Your Email</label>
            </div>
            <div class="form-group">
              <button type="submit" class="btn btn-primary btn-block">Reset Password</button>
            </div>
          </form>
          <?php echo $__env->make("partials.auth_footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
      </div>
    </body>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.auth", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8.0.11\htdocs\dest\DEST\resources\views/auth/forgot-password.blade.php ENDPATH**/ ?>