 

  <?php $__env->startSection("title"); ?>
      Login
  <?php $__env->stopSection(); ?>
    
  <?php $__env->startPush('head'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('assets/examples/css/pages/login-v2.minfd53.css?v4.0.1')); ?>">
  <?php $__env->stopPush(); ?>

  <?php $__env->startSection("content"); ?>
    <body class="animsition page-login-v2 layout-full page-dark">
      <div class="page" data-animsition-in="fade-in" data-animsition-out="fade-out">
        <div class="page-content">
          <div class="page-brand-info">
            <div class="brand">
              <img class="brand-img" src="<?php echo e(asset('assets/images/DEST_logo.png')); ?>" alt="..."> 
              <hr>
              <h1 style="color:white; background-color:darkblue; font-weight: bold; font-style: italic; font-size: 40px;">Welcome to DEST Student Portal</h1>
            </div>
          </div>
          <div class="page-login-main">
            <div class="brand hidden-md-up">
              <img class="brand-img" src="<?php echo e(asset('assets/images/run_logo.png')); ?>" alt="..."><span class="brand-text font-size-30">RUN DEST</span>
            </div>
            <h3 class="font-size-24">Log In</h3>
            <p>Log in with your email and password</p>
             
            <?php if(Session::get('pass_reset')): ?>
                <div class="alert dark alert-icon alert-danger alert-dismissible" role="alert">
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                  <i class="icon md-close" aria-hidden="true"></i> <?php echo e(Session::get('pass_reset')); ?>

                </div>
            <?php endif; ?>
            
            <?php if(Session::get('verified')): ?>
                <div class="alert dark alert-icon alert-success alert-dismissible" role="alert">
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                  <i class="icon md-close" aria-hidden="true"></i> <?php echo e(Session::get('verified')); ?>

                </div>
            <?php endif; ?>
         
              <?php if(Session::get('success')): ?>
                <p><?php echo e(Session::get('success')); ?></p>
              <?php endif; ?>
              <?php if(Session::get('fail')): ?>
                <div class="alert dark alert-icon alert-danger alert-dismissible" role="alert">
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                  <i class="icon md-close" aria-hidden="true"></i> <?php echo e(Session::get('fail')); ?>

                </div>
              <?php endif; ?>
            <form action="<?php echo e(route('auth.check')); ?>" method="post" autocomplete="off">
              <?php echo csrf_field(); ?>
              <div class="form-group form-material floating" data-plugin="formMaterial">
                <input type="email" class="form-control empty" id="inputEmail" name="email" required>
                <label class="floating-label" for="inputEmail">Email</label>
              </div>
              <div class="form-group form-material floating" data-plugin="formMaterial">
                <input type="password" class="form-control empty" id="inputPassword" name="password" required>
                <label class="floating-label" for="inputPassword">Password</label>
              </div>
              <div class="form-group clearfix">
                <div class="checkbox-custom checkbox-inline checkbox-primary float-left">
                  <input type="checkbox" id="remember" name="checkbox">
                  <label for="inputCheckbox">Remember me</label>
                </div>
                <a class="float-right" href="<?php echo e(route('forgot.password')); ?>">Forgot password?</a>
              </div>
              <button type="submit" class="btn btn-primary btn-block">Log in</button>
            </form>
            <p>No account? <a href="<?php echo e(route('get.account.form')); ?>">Create Profile here</a></p>
            <?php echo $__env->make("partials.auth_footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </div>
        
        </div>
      </div>
    </body>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.auth", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8.0.11\htdocs\dest\DEST\resources\views/auth/login.blade.php ENDPATH**/ ?>