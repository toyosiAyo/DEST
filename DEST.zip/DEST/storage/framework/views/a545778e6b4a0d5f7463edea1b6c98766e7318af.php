<footer class="site-footer">
    <div class="site-footer-legal">© <script>document.write(new Date().getFullYear())</script> <a href="#">RUN DEST</a></div>
    <!-- <div class="site-footer-right">
      Crafted with <i class="red-600 icon md-favorite"></i> by <a href="#">RUN ICT</a>
    </div> -->
</footer><?php /**PATH C:\xampp8.0.11\htdocs\dest\DEST\resources\views/partials/footer.blade.php ENDPATH**/ ?>