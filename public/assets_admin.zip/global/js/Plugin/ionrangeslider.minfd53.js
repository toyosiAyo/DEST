/*!
 * Remark Material (http://getbootstrapadmin.com/remark)
 * Copyright 2017 amazingsurge
 * Licensed under the Themeforest Standard Licenses
 */

!function(global,factory){if("function"==typeof define&&define.amd)define("/Plugin/ionrangeslider",["exports","Plugin"],factory);else if("undefined"!=typeof exports)factory(exports,require("Plugin"));else{var mod={exports:{}};factory(mod.exports,global.Plugin),global.PluginIonrangeslider=mod.exports}}(this,function(exports,_Plugin2){"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var _Plugin3=babelHelpers.interopRequireDefault(_Plugin2),NAME="ionRangeSlider",IonRangeSlider=function(_Plugin){function IonRangeSlider(){return babelHelpers.classCallCheck(this,IonRangeSlider),babelHelpers.possibleConstructorReturn(this,(IonRangeSlider.__proto__||Object.getPrototypeOf(IonRangeSlider)).apply(this,arguments))}return babelHelpers.inherits(IonRangeSlider,_Plugin),babelHelpers.createClass(IonRangeSlider,[{key:"getName",value:function(){return NAME}}]),IonRangeSlider}(_Plugin3.default);_Plugin3.default.register(NAME,IonRangeSlider),exports.default=IonRangeSlider});